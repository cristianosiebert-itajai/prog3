var fs = require('fs');
var express = require('express');
var bodyParser = require('body-parser');
var app = express();
app.use(bodyParser.json());

const lerArquivo = async () => {
  const banco = "banco_livros.csv";
  const livros = [];
  const data = fs.readFileSync(banco, 'utf8');
  const linhas = data.split('\n');
  const cabecalho = linhas[0].split(',');
  for (let i = 1; i < linhas.length; i++) {
    const valores = linhas[i].split(',');
    const livro = {};
    for (let i = 0; i < cabecalho.length; i++) {
      livro[cabecalho[i]] = valores[i];
    }
    livros.push(livro);
  }
  return livros;
};

const livrosAtivos = (livros) => {
  return livros.filter((livro) => {
    return livro.ativo === "true";
  });
}

const buscarLivro = (livros, livro) => {
  const livrosFiltrados = livros.filter((item) => {
    return item.nome.toLowerCase().includes(livro.toLowerCase());
  });
  return livrosFiltrados;
}

const buscarLivroPorId = (livros, id) => {
  const livrosFiltrados = livros.filter((item) => {
    return item.id === id;
  });
  return livrosFiltrados;
}

const salvarLivro = async (livro, livros) => {
  const banco = "banco_livros.csv";
  const newId = livros.length + 1;
  const linha = `${newId},${livro.nome},true`;
  const data = fs.readFileSync(banco, 'utf8');
  await fs.writeFile(banco, `${data}\n${linha}`, () => {});
}

const updateLivro = async (body, id, livros) => {
  let txtParaSalvar = 'id,nome,ativo\n';
  livros.map((item) => {
    if (item.id === id) {
      item.nome = body.nome;
    }
    txtParaSalvar += `${item.id},${item.nome},${item.ativo}\n`;
  });
  txtParaSalvar = txtParaSalvar.slice(0, -2);
  const banco = "banco_livros.csv";
  await fs.writeFile(banco, `${txtParaSalvar}`, () => {});
};

const softDelete = async (id, livros) => {
  let txtParaSalvar = 'id,nome,ativo\n';
  livros.map((item) => {
    if (item.id === id) {
      item.ativo = false;
    }
    txtParaSalvar += `${item.id},${item.nome},${item.ativo}\n`;
  });
  txtParaSalvar = txtParaSalvar.slice(0, -1);
  const banco = "banco_livros.csv";
  await fs.writeFile(banco, `${txtParaSalvar}`, () => {});
};

const hardDelete = async (id, livros) => {
  let txtParaSalvar = 'id,nome,ativo\n';
  livros.map((item) => {
    if (item.id !== id) {
      txtParaSalvar += `${item.id},${item.nome},${item.ativo}\n`;
    }
  });
  txtParaSalvar = txtParaSalvar.slice(0, -1);
  const banco = "banco_livros.csv";
  await fs.writeFile(banco, `${txtParaSalvar}`, () => {});
};

app.get('/livros', async (req, res) => {
  const livros = await lerArquivo();
  res.send(livros);
});

app.get('/livros-ativos', async (req, res) => {
  const livros = await lerArquivo();
  const ativos = livrosAtivos(livros);
  res.send(ativos);
});

app.get('/livros/:title', async (req, res) => {
  const title = req.params.title;
  const livros = await lerArquivo();
  const livro = buscarLivro(livros, title);
  res.send(livro);
});

app.get('/livros-by-id/:id', async (req, res) => {
  const id = req.params.id;
  const livros = await lerArquivo();
  const livro = buscarLivroPorId(livros, id);
  res.send(livro);
});

app.post('/livros', async (req, res) => {
  const livro = req.body;
  const livros = await lerArquivo();
  salvarLivro(livro, livros);
  res.send('OK');
});

app.put('/livros/:id', async (req, res) => {
  const body = req.body;
  const id = req.params.id;
  const livros = await lerArquivo();
  const livro = await buscarLivroPorId(livros, id);
  if (livro) {
    updateLivro(body, id, livros);
  }
  res.send('OK');
});

app.put('/livros-soft-delete/:id', async (req, res) => {
  const id = req.params.id;
  const livros = await lerArquivo();
  const livro = await buscarLivroPorId(livros, id);
  if (livro) {
    softDelete(id, livros);
  }
  res.send('Removed');
});

app.delete('/livros/:id', async (req, res) => {
  const id = req.params.id;
  const livros = await lerArquivo();
  const livro = await buscarLivroPorId(livros, id);
  if (livro) {
    hardDelete(id, livros);
  }
  res.send('Deleted');
});

const porta = 8005;
app.listen(porta, () => {
  console.log('Servidor ativo na porta ' + porta);
});